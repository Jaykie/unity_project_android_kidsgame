package com.moonma.common;

import android.app.Activity;

import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.RelativeLayout;
//import com.baidu.mobads.*;
import com.qq.e.ads.interstitial.AbstractInterstitialADListener;
import com.qq.e.ads.interstitial.InterstitialAD;
import org.json.JSONObject;

import com.moonma.common.IAdInsertBase;
import com.moonma.common.IAdInsertBaseListener;
import com.moonma.common.AdConfigGdt;
import com.qq.e.comm.util.AdError;

public class AdInsertGdt implements IAdInsertBase {

	// 自定义单一平台广告视图对象
	//private AdView adView;
    InterstitialAD iad;
    private static String TAG = "AdInsert";

    public boolean isUseActivity = false;//true
    boolean isAdInit;
    FrameLayout framelayout;
    Activity mainActivity;
    private   boolean sIsShow;
    private   int bannerOffsety;
    private   float bannerAlhpha;

   // InterstitialAd interAd;

    private IAdInsertBaseListener adInsertBaseListener;

    public   void init(  Activity activity,FrameLayout layout)
    {
        mainActivity = activity;
        framelayout = layout;
        isAdInit = false;
    }


     public void setAd()
    {

        if(isAdInit==false)
        {
            isAdInit = true; String strAppId = AdConfigGdt.main().appId;
            String strAppKey = AdConfigGdt.main().appKeyInsert;
            Log.i(TAG, "insert id="+strAppId+ " key="+strAppKey);

            if (iad == null) {
                iad = new InterstitialAD(mainActivity, strAppId, strAppKey);
            }

            iad.setADListener(new AbstractInterstitialADListener() {

                @Override
                public void onNoAD(AdError var1) {
                   // Log.i(TAG, "LoadInterstitialAd Fail:" + arg0);
                    if (adInsertBaseListener!=null){
                        adInsertBaseListener.adInsertDidFail();

                    }
                }

                @Override
                public void onADReceive() {
                    Log.i(TAG, "onADReceive");
                   iad.show();
                   // iad.showAsPopupWindow();



//                    mainActivity.runOnUiThread( new Runnable()
//                    {
//                        @Override
//                        public void run()
//                        {
//                            Log.i("AD_DEMO", "onADReceive runOnUiThread");
//                            iad.show();
//
//                        }
//                    } );
                   // iad.showAsPopupWindow();
                }

                @Override
                public void onADClosed() {

                    if (adInsertBaseListener!=null){
                        adInsertBaseListener.adInsertDidClose();

                    }
                }

                @Override
                public void onADOpened() {
                    if (adInsertBaseListener!=null){
                        adInsertBaseListener.adInsertWillShow();

                    }
                }

                @Override
                public void onADExposure() {

                }


            });


        }

    }
    
    public void show( )
    {


        mainActivity.runOnUiThread( new Runnable()
        {
            @Override
            public void run()
            {

                iad.loadAD();
                //iad.show();

            }
        } );
    }

    public void setListener(IAdInsertBaseListener listener)
    {
        adInsertBaseListener = listener;
    }

    public void startSplashAd(final String strAppId, final String strAppKey) {


    }



    public interface OnAdInsertListener {

        void adInsertWillShow();
        void adInsertDidClose();
    }
}
