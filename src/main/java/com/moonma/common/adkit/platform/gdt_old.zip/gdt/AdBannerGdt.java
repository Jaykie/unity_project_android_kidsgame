package com.moonma.common;

import android.app.Activity;

import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.RelativeLayout;

import com.moonma.common.IAdBannerBase;
import com.moonma.common.IAdBannerBaseListener;
import com.moonma.common.AdConfigGdt;

import com.qq.e.ads.banner.ADSize;
import com.qq.e.ads.banner.AbstractBannerADListener;
import com.qq.e.ads.banner.BannerView;
import com.qq.e.comm.util.AdError;

import org.json.JSONObject;

public class AdBannerGdt implements IAdBannerBase {

    // 自定义单一平台广告视图对象
    // private AdView adView;
    BannerView bv;
    private static String TAG = "AdBanner";

    FrameLayout framelayout;
    Activity mainActivity;
    private boolean sIsShow;
    private int bannerOffsety;
    private float bannerAlhpha;

    // AdView adView;
    FrameLayout framelayoutAd;
    IAdBannerBaseListener adBannerBaseListener;
    boolean isAdInit;

    public void init(Activity activity, FrameLayout layout) {
        mainActivity = activity;
        framelayout = layout;
        isAdInit = false;
        sIsShow = false;

    }

    public void setAd() {
        if (isAdInit == false) {
            isAdInit = true;

            String strAppId = AdConfigGdt.main().appId;
            String strAppKey = AdConfigGdt.main().appKeyBanner;

            Log.i("AD_DEMO", "banner id=" + strAppId + " key=" + strAppKey);

            this.bv = new BannerView(mainActivity, ADSize.BANNER, strAppId, strAppKey);
            // 注意：如果开发者的banner不是始终展示在屏幕中的话，请关闭自动刷新，否则将导致曝光率过低。
            // 并且应该自行处理：当banner广告区域出现在屏幕后，再手动loadAD。
            bv.setRefresh(30);
            bv.setADListener(new AbstractBannerADListener() {

                @Override
                public void onNoAD(AdError var1){
                  //  Log.i("AD_DEMO", "BannerNoAD，eCode=" + arg0);
                    if (adBannerBaseListener != null) {
                        adBannerBaseListener.onLoadAdFail();
                    }
                }

                @Override
                public void onADReceiv() {

                    Log.i("AD_DEMO", "ONBannerReceive");
                    if (adBannerBaseListener != null) {
                        int w, h;
                        w = bv.getWidth();
                        h = bv.getHeight();
                        adBannerBaseListener.onReceiveAd(w, h);

                        setOffsetY(bannerOffsety);
                    }
                }
            });

            // 将adView添加到父控件中(注：该父控件不一定为您的根控件，只要该控件能通过addView能添加广告视图即可)
            RelativeLayout.LayoutParams rllp = new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.FILL_PARENT,
                    RelativeLayout.LayoutParams.WRAP_CONTENT);
            rllp.addRule(RelativeLayout.ALIGN_PARENT_BOTTOM);
            // rllp.addRule(RelativeLayout.CENTER_HORIZONTAL);

            // FrameLayout
            ViewGroup.LayoutParams framelayout_params = new ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT);
            framelayoutAd = new FrameLayout(mainActivity);
            framelayoutAd.setLayoutParams(framelayout_params);

            framelayoutAd.addView(bv);
            framelayout.addView(framelayoutAd, rllp);

            // adView.setVisibility(View.GONE);
            framelayoutAd.setVisibility(View.GONE);

            bv.loadAD();
        }

    }

    public void setAlpha(float alpha) {

        bannerAlhpha = alpha;
        if (mainActivity == null) {
            return;
        }
        mainActivity.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (bannerAlhpha < 1.0) {
                    // bannerAlhpha =0;
                }
                framelayoutAd.setAlpha(bannerAlhpha);

            }
        });

    }

    public void show(boolean isShow) {
        sIsShow = isShow;

        if (mainActivity == null) {
            return;
        }

        mainActivity.runOnUiThread(new Runnable() {
            @Override
            public void run() {

                if (bv == null) {
                    return;
                }
                if (sIsShow) {

                    // bv.loadAD();
                    framelayoutAd.setVisibility(View.VISIBLE);

                } else {

                    framelayoutAd.setVisibility(View.GONE);
                }
            }
        });

    }

    public void layoutSubView(int w, int h) {
        setOffsetY(bannerOffsety);

    }

    public void setOffsetY(int y) {

        bannerOffsety = y;
        //
        //
        if ((bv == null) || (framelayout == null) || (mainActivity == null)) {
            return;
        }
        mainActivity.runOnUiThread(new Runnable() {
            @Override
            public void run() {

                int screen_w = framelayout.getWidth();
                int w = bv.getWidth();
                int screen_h = framelayout.getHeight();
                int h = bv.getHeight();

                int x = (screen_w - w) / 2;
                int y = screen_h - h - bannerOffsety-ScreenUtil.getBottomNavigationBarHeight();

                if (h == 0) {
                    // 显示到屏幕外
                    // y = screen_h;

                }
                // adView.setX(x);
                // adView.setY(y);

                framelayoutAd.setX(x);
                framelayoutAd.setY(y);

                // FrameLayout.LayoutParams cameraFL = new FrameLayout.LayoutParams(w,
                // h,Gravity.TOP); // set size
                // cameraFL.setMargins(x, y, 0, 0); // set position
                // adsMogoLayoutCode.setLayoutParams(cameraFL);

                bv.setY(0);
                bv.bringToFront();
                framelayoutAd.bringToFront();
            }
        });

    }

    public void setListener(IAdBannerBaseListener listener) {
        adBannerBaseListener = listener;

    }

    public interface OnAdBannerListener {

        void onReceiveAd(int w, int h);
    }
}
